let owlImage;

function game1Preload(){
  owlImage = loadImage("Game1/owlCarving.jpg");
}

function game1Setup(){
  background('#fae');
  currentActivity = 1;
  createCanvas(400, 400);
  noLoop();
  
  // Hide the Game 1 button, show all the other navigation buttons
  menuButton.show();
  game1Button.hide();
  game2Button.hide();
  game3Button.hide();
  
  // Set the size of the owl image
  owlImage.resize(150, 150);
}
let user;
let x=100;
let y=115;
function game1Draw(){
  background('#fae');
  
  
 
  
  
  
}
 
