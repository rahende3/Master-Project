let owlImage;

function game1Preload(){
  owlImage = loadImage("Game1/owlCarving.jpg");
}

function game1Setup(){
  background('#fae');
  currentActivity = 1;
  createCanvas(400, 400);
  noLoop();
  
  // Hide the Game 1 button, show all the other navigation buttons
  menuButton.show();
  game1Button.hide();
  game2Button.hide();
  game3Button.hide();
  
  // Set the size of the owl image
  owlImage.resize(150, 150);
}
let user;
let x=100;
let y=115;
function game1Draw(){
  background('#fae');
  
  
  fill('yellow');
  let userMouse;
  userMouse = circle(mouseX,mouseY,20);
  fill('black');
  text('Follow the Maze!', 110, 40);
  fill('green');
  text('Start',60,80);
  fill('red');
  text('End',300,275);
  //Barriers
  line(50,50,350,50);
  line(50,50,50,350);
  line(50,350,350,350);
  line(350,350,350,50);
  //Center Lines
  line(50,150,250,150);
  line(350,250,150,250);
  

  
  fill('blue');
  user = circle(x,y,50);
  
  
  if(x<250 && y>150){
    fill('red');
    text('Fail',160,200);
    x = 100;
    y = 115;
  }
}
 
