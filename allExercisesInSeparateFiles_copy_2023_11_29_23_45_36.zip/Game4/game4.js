function game4Preload(){
  
}

function game4Setup(){
  background("white");
  currentActivity = 4;
}

function game4Draw(){
  background("white");
  /*
  menuButton.position(0, 0);
  menuButton.mousePressed(switchToMM);
  menuButton.hide();
  
  game1Button = createButton('Game 1');
  game1Button.position(10, 50);
  game1Button.mousePressed(game1Setup);
  game1Button.show();
  
  game2Button = createButton('Game 2');
  game2Button.position(10, 100);
  game2Button.mousePressed(game2Setup);
  game2Button.show();
  
  game3Button = createButton('Game 3');
  game3Button.position(10, 150);
  game3Button.mousePressed(game3Setup);
  game3Button.show();
  */
  
  fill("white");
  rect(10, 10, 100, 25);
  fill("black");
  text("Home Page", 25, 25);
  
  fill('black');
  text('Activity 4 goes here', 200, 200);
}

/*****
* Instead of using buttons like other games, this example draws 
* rectangles and circles. The mousePressed function determines if the
* user clicked on one of the shapes.
*****/
function game4MousePressed(){
  
}